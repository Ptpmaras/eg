import discord
import gspread
from oauth2client.service_account import ServiceAccountCredentials
import os
from dotenv import load_dotenv
from datetime import datetime

# Load environment variables
load_dotenv()
DISCORD_TOKEN = os.getenv("DISCORD_TOKEN")
SHEET_NAME = os.getenv("SHEET_NAME")

# Discord setup
intents = discord.Intents.default()
intents.message_content = True
client = discord.Client(intents=intents)

# Google Sheets setup
scope = ["https://spreadsheets.google.com/feeds", "https://www.googleapis.com/auth/drive"]
creds = ServiceAccountCredentials.from_json_keyfile_name("creds.json", scope)
sheet = gspread.authorize(creds).open(SHEET_NAME).sheet1

# Parse expense text (without GPT)
def parse_expense_text(text):
    parts = [x.strip() for x in text.split(',')]

    if len(parts) == 3:
        date = datetime.today().strftime('%Y-%m-%d')
        return [date] + parts  # [date, item, amount, category]
    elif len(parts) == 4:
        return parts  # [date, item, amount, category]
    else:
        return None

@client.event
async def on_ready():
    print(f"✅ Logged in as {client.user}")

@client.event
async def on_message(message):
    print(f"📩 Message received: {message.content} from {message.author}")

    if message.author == client.user:
        return

    if message.content.startswith("!log "):
        expense_text = message.content[5:]
        print(f"📝 Logging: {expense_text}")

        parsed = parse_expense_text(expense_text)

        if parsed:
            try:
                print(f"📤 Writing to Google Sheet: {parsed}")
                sheet.append_row(parsed)
                await message.channel.send(f"✅ Expense logged: `{', '.join(parsed)}`")
            except Exception as e:
                print(f"❌ Failed to write to Google Sheets: {e}")
                await message.channel.send("❌ Failed to log expense to Google Sheet.")
        else:
            await message.channel.send("❌ Please format as: `item, amount, category` or `date, item, amount, category`")

# Start the bot
client.run(DISCORD_TOKEN)

