#!/usr/bin/env python3
import os

def generate_bot_invite_url():
    """Generate Discord bot invite URL"""
    
    # Get the bot's application ID from the token
    token = os.environ.get("DISCORD_BOT_TOKEN", "").strip()
    if not token:
        print("❌ No Discord token found")
        return
    
    # Extract application ID from token (first part before first dot)
    try:
        app_id = token.split('.')[0]
        # Decode base64 to get actual application ID
        import base64
        decoded = base64.b64decode(app_id + '==')  # Add padding
        application_id = decoded.decode('utf-8')
        print(f"Application ID: {application_id}")
    except Exception as e:
        print(f"Could not extract application ID: {e}")
        application_id = "YOUR_APPLICATION_ID"
    
    # Generate invite URL with necessary permissions
    base_url = "https://discord.com/api/oauth2/authorize"
    permissions = 2147483648 + 277025770496  # Bot + slash commands + send messages + read message history
    
    invite_url = f"{base_url}?client_id={application_id}&permissions={permissions}&scope=bot%20applications.commands"
    
    print("\n🔗 Discord Bot Invite URL:")
    print(invite_url)
    print("\n📋 Steps to add bot to your server:")
    print("1. Copy the URL above")
    print("2. Paste it in your browser") 
    print("3. Select your Discord server")
    print("4. Authorize the bot")
    print("5. Test with: !log test, 5.00, food")

if __name__ == "__main__":
    generate_bot_invite_url()