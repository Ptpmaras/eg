import os
import discord
from discord.ext import commands
from datetime import datetime
import gspread
from oauth2client.service_account import ServiceAccountCredentials
from keep_alive import keep_alive
from dotenv import load_dotenv

# Load environment variables from .env
load_dotenv()

# Set up intents
intents = discord.Intents.default()
intents.message_content = True

# Create bot instance
bot = commands.Bot(command_prefix='!', intents=intents)

# Google Sheets setup
scope = [
    "https://spreadsheets.google.com/feeds",
    "https://www.googleapis.com/auth/drive",
]

try:
    creds = ServiceAccountCredentials.from_json_keyfile_name("creds.json", scope)
    client = gspread.authorize(creds)
    sheet = client.open("Daily Expenses Bot").sheet1
    print("✅ Google Sheet connected")
except Exception as e:
    print(f"❌ Failed to connect to Google Sheet: {e}")
    sheet = None

# Keep the Replit bot alive
keep_alive()

@bot.event
async def on_ready():
    print(f"✅ Logged in as {bot.user}")

@bot.command()
async def ping(ctx):
    await ctx.send("🏓 Pong!")

@bot.command()
async def log(ctx, item: str, amount: float, *, note: str = ""):
    """Log an expense"""
    if sheet:
        try:
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M")
            user = ctx.author.name
            sheet.append_row([timestamp, item, amount, note, user])
            await ctx.send(f"✅ Logged `{item}` - RM{amount:.2f} by {user}")
        except Exception as e:
            await ctx.send(f"❌ Failed to write to Google Sheet: {e}")
    else:
        await ctx.send("❌ Google Sheet is not connected.")

# Run bot
token = os.getenv("DISCORD_BOT_TOKEN")
if token:
    bot.run(token)
else:
    print("❌ DISCORD_BOT_TOKEN is not set in .env")
