# Discord Expense Bot

## Overview

This is a Flask-based web application that integrates with Discord to provide expense tracking functionality through Discord slash commands. The application allows users to add, view, and manage their personal expenses directly through Discord interactions, with a web dashboard for monitoring and administration.

## User Preferences

Preferred communication style: Simple, everyday language.

## Recent Changes (July 25, 2025)

✓ Integrated existing Google Sheets Discord bot with Flask web dashboard
✓ Added dual storage: Google Sheets + in-memory database for web interface
✓ Support for both !log commands and modern slash commands
✓ Fixed Google Sheets authentication with complete service account credentials
✓ Auto-creation of Google Sheets if they don't exist
✓ Real-time bot status monitoring in web dashboard

## System Architecture

The application follows a modular architecture with clear separation of concerns:

- **Web Layer**: Flask application serving a dashboard and handling Discord webhook interactions
- **Bot Layer**: Discord bot implementation using discord.py for slash command handling
- **Business Logic Layer**: ExpenseManager class for expense operations and data management
- **Data Layer**: In-memory storage using Python dictionaries (designed to be easily replaceable with a database)

## Key Components

### Flask Web Application (`app.py`)
- **Purpose**: Serves as the main web interface and Discord webhook handler
- **Key Features**: 
  - Dashboard showing bot status and expense statistics
  - Admin view for all expenses
  - Discord interaction endpoint (webhook handling)
- **Technology**: Flask with Werkzeug middleware for proxy handling

### Discord Bot (`bot.py`)
- **Purpose**: Handles Discord slash command interactions
- **Key Features**:
  - Slash command registration and syncing
  - User interaction handling
  - Integration with ExpenseManager for data operations
- **Technology**: discord.py library with proper intents configuration

### Expense Manager (`expense_manager.py`)
- **Purpose**: Core business logic for expense tracking
- **Key Features**:
  - CRUD operations for expenses
  - Category validation
  - User-based expense organization
  - In-memory data storage with defaultdict structure
- **Data Model**: Each expense contains id, amount, description, category, date, and user_id

### Frontend Templates
- **Dashboard** (`templates/index.html`): Shows bot status and basic statistics
- **Expenses View** (`templates/expenses.html`): Administrative view of all user expenses
- **Styling**: Bootstrap 5 with dark theme and Font Awesome icons

## Data Flow

1. **Discord Command Flow**:
   - User issues slash command in Discord
   - Discord sends interaction to bot
   - Bot processes command and calls ExpenseManager
   - ExpenseManager updates in-memory storage
   - Bot responds to user with confirmation

2. **Web Dashboard Flow**:
   - User visits web dashboard
   - Flask app queries ExpenseManager for statistics
   - Template renders current bot status and expense data
   - Real-time status reflects Discord bot connection state

## External Dependencies

### Core Dependencies
- **Flask**: Web framework for dashboard and webhook handling
- **discord.py**: Discord API integration and bot functionality
- **Werkzeug**: WSGI utilities and proxy middleware

### Frontend Dependencies
- **Bootstrap 5**: UI framework with dark theme
- **Font Awesome**: Icon library for enhanced UX

### Environment Variables
- `DISCORD_BOT_TOKEN`: Required for Discord bot authentication
- `SESSION_SECRET`: Flask session security (optional, has default)

## Deployment Strategy

### Current Setup
- **Development**: Flask development server on port 5000
- **Entry Point**: `main.py` imports and runs the Flask app
- **Static Assets**: Served directly by Flask from `/static` directory
- **Templates**: Jinja2 templates in `/templates` directory

### Production Considerations
- Application is configured for proxy deployment with ProxyFix middleware
- Bot token should be securely managed through environment variables
- In-memory storage needs replacement with persistent database for production
- Discord webhook verification should be implemented for security

### Scalability Notes
- Current in-memory storage is not persistent and doesn't scale across instances
- ExpenseManager is designed to be easily replaced with database-backed implementation
- Bot and web components can be separated into different services if needed
- Consider implementing user authentication for web dashboard in production

The architecture prioritizes simplicity and modularity, making it easy to extend with additional features like expense categories, reporting, or database persistence while maintaining clear separation between Discord bot functionality and web dashboard features.