#!/usr/bin/env python3
import os
import gspread
from oauth2client.service_account import ServiceAccountCredentials

def test_google_sheets():
    """Test Google Sheets connection and permissions"""
    try:
        if not os.path.exists("creds.json"):
            print("❌ Missing creds.json file")
            return
        
        # Set up credentials
        scope = ["https://spreadsheets.google.com/feeds", "https://www.googleapis.com/auth/drive"]
        creds = ServiceAccountCredentials.from_json_keyfile_name("creds.json", scope)
        gc = gspread.authorize(creds)
        
        print("✅ Google Sheets authentication successful")
        
        # List existing spreadsheets
        try:
            sheets = gc.list_spreadsheet_files()
            print(f"📋 Found {len(sheets)} existing spreadsheets:")
            for sheet in sheets[:5]:  # Show first 5
                print(f"  - {sheet['name']} (ID: {sheet['id'][:20]}...)")
        except Exception as e:
            print(f"⚠️  Could not list spreadsheets: {e}")
        
        # Try to create a test sheet
        test_name = "Test Expense Sheet"
        try:
            print(f"🔧 Attempting to create test sheet: {test_name}")
            test_sheet = gc.create(test_name)
            print(f"✅ Successfully created test sheet!")
            print(f"📄 Sheet URL: https://docs.google.com/spreadsheets/d/{test_sheet.id}")
            
            # Delete test sheet
            gc.del_spreadsheet(test_sheet.id)
            print("🗑️  Cleaned up test sheet")
            
        except Exception as e:
            print(f"❌ Could not create sheet: {e}")
            print("💡 Solution: Please manually create a Google Sheet named 'Daily Expenses Bot'")
            print("   Then share it with the service account email from creds.json")
        
    except Exception as e:
        print(f"❌ Authentication failed: {e}")

if __name__ == "__main__":
    test_google_sheets()