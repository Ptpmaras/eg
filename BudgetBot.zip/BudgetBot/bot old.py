from keep_alive import keep_alive
keep_alive()
import os
import logging
import discord
from discord.ext import commands
from expense_manager import ExpenseManager
import asyncio
import gspread
from oauth2client.service_account import ServiceAccountCredentials
from datetime import datetime

logger = logging.getLogger(__name__)

class DiscordBot:
    def __init__(self, expense_manager: ExpenseManager):
        self.expense_manager = expense_manager
        self.bot_token = os.environ.get("DISCORD_BOT_TOKEN")
        self.sheet_name = os.environ.get("SHEET_NAME", "Daily Expenses Bot")
        # Force use of clean sheet name regardless of environment variable
        if self.sheet_name and (self.sheet_name.startswith("MTM") or len(self.sheet_name) > 50):
            self.sheet_name = "Daily Expenses Bot"
        self.ready = False
        
        # Configure Discord intents with message content enabled
        intents = discord.Intents.default()
        intents.message_content = True  # Now enabled in Discord portal
        
        # Create bot instance
        self.bot = commands.Bot(command_prefix='!', intents=intents)
        
        # Initialize Google Sheets (optional)
        self.sheet = None
        self.init_google_sheets()
        
        # Register event handlers
        self.bot.event(self.on_ready)
        self.bot.event(self.on_message)
        
        # Register slash commands
        self.register_commands()
    
    def init_google_sheets(self):
        """Initialize Google Sheets connection"""
        try:
            if os.path.exists("creds.json") and self.sheet_name:
                scope = ["https://spreadsheets.google.com/feeds", "https://www.googleapis.com/auth/drive"]
                creds = ServiceAccountCredentials.from_json_keyfile_name("creds.json", scope)
                gc = gspread.authorize(creds)
                
                # Try to open the sheet, if it doesn't exist, create it
                try:
                    self.sheet = gc.open(self.sheet_name).sheet1
                    logger.info(f"Connected to existing Google Sheet: {self.sheet_name}")
                except gspread.SpreadsheetNotFound:
                    # Create new spreadsheet
                    spreadsheet = gc.create(self.sheet_name)
                    self.sheet = spreadsheet.sheet1
                    
                    # Set up headers
                    self.sheet.append_row(['Date', 'Item', 'Amount', 'Category'])
                    logger.info(f"Created new Google Sheet: {self.sheet_name}")
                    
                    # Share with your email (optional)
                    # spreadsheet.share('your-email@gmail.com', perm_type='user', role='writer')
                    
        except Exception as e:
            logger.error(f"Could not connect to Google Sheets: {e}")
            self.sheet = None
    
    async def on_ready(self):
        """Called when the bot is ready"""
        logger.info(f'{self.bot.user} has connected to Discord!')
        self.ready = True
        
        # Sync slash commands
        try:
            synced = await self.bot.tree.sync()
            logger.info(f"Synced {len(synced)} command(s)")
        except Exception as e:
            logger.error(f"Failed to sync commands: {e}")
    
    async def on_message(self, message):
        """Handle incoming messages for !log command"""
        if message.author == self.bot.user:
            return
        
        # Handle !log command for backwards compatibility
        if message.content.startswith("!log "):
            expense_text = message.content[5:]
            logger.info(f"Processing !log command: {expense_text}")
            
            parsed = self.parse_expense_text(expense_text)
            if parsed:
                # Add to in-memory storage
                try:
                    expense_id = self.expense_manager.add_expense(
                        user_id=str(message.author.id),
                        amount=float(parsed[2]),
                        description=parsed[1],
                        category=parsed[3] if len(parsed) > 3 else "other"
                    )
                    
                    # Also add to Google Sheets if available
                    if self.sheet:
                        try:
                            self.sheet.append_row(parsed)
                            await message.channel.send(f"✅ Expense logged: `{', '.join(parsed)}` (ID: {expense_id})")
                        except Exception as e:
                            logger.error(f"Failed to write to Google Sheets: {e}")
                            await message.channel.send(f"✅ Expense logged locally: `{', '.join(parsed)}` (ID: {expense_id})\n⚠️ Could not sync to Google Sheets")
                    else:
                        await message.channel.send(f"✅ Expense logged: `{', '.join(parsed)}` (ID: {expense_id})")
                        
                except Exception as e:
                    logger.error(f"Failed to add expense: {e}")
                    await message.channel.send("❌ Failed to log expense.")
            else:
                await message.channel.send("❌ Please format as: `item, amount, category` or `date, item, amount, category`")
    
    def parse_expense_text(self, text):
        """Parse expense text for !log command"""
        parts = [x.strip() for x in text.split(',')]
        
        if len(parts) == 3:
            date = datetime.today().strftime('%Y-%m-%d')
            return [date] + parts  # [date, item, amount, category]
        elif len(parts) == 4:
            return parts  # [date, item, amount, category]
        else:
            return None
    
    def is_ready(self):
        """Check if bot is ready and connected"""
        return self.ready and self.bot.is_ready()
    
    def register_commands(self):
        """Register all slash commands"""
        
        @self.bot.tree.command(name="add_expense", description="Add a new expense")
        @discord.app_commands.describe(
            amount="Amount spent (e.g., 12.50)",
            description="Description of the expense",
            category="Category (food, transport, utilities, entertainment, shopping, rumah, bills, setel, maybank cc, spay later, invest, TnG,other)"
        )
        async def add_expense(interaction: discord.Interaction, amount: str, description: str, category: str = "other"):
            try:
                # Validate amount
                try:
                    amount_float = float(amount.replace('$', '').replace(',', ''))
                    if amount_float <= 0:
                        await interaction.response.send_message("❌ Amount must be greater than 0", ephemeral=True)
                        return
                except ValueError:
                    await interaction.response.send_message("❌ Invalid amount format. Please use numbers only (e.g., 12.50)", ephemeral=True)
                    return
                
                # Validate category
                valid_categories = ["food", "transport", "utilities", "entertainment", "shopping", "rumah", "bills", "setel", "maybank cc", "spay later","other"]
                if category.lower() not in valid_categories:
                    await interaction.response.send_message(f"❌ Invalid category. Valid categories: {', '.join(valid_categories)}", ephemeral=True)
                    return
                
                # Add expense
                expense_id = self.expense_manager.add_expense(
                    user_id=str(interaction.user.id),
                    amount=amount_float,
                    description=description,
                    category=category.lower()
                )
                
                embed = discord.Embed(
                    title="✅ Expense Added",
                    color=0x00ff00,
                    description=f"**Amount:** ${amount_float:.2f}\n**Description:** {description}\n**Category:** {category.title()}"
                )
                embed.set_footer(text=f"Expense ID: {expense_id}")
                
                await interaction.response.send_message(embed=embed)
                
            except Exception as e:
                logger.error(f"Error adding expense: {e}")
                await interaction.response.send_message("❌ An error occurred while adding the expense", ephemeral=True)
        
        @self.bot.tree.command(name="view_expenses", description="View your expenses")
        @discord.app_commands.describe(
            category="Filter by category (optional)",
            limit="Number of recent expenses to show (default: 10)"
        )
        async def view_expenses(interaction: discord.Interaction, category: str | None = None, limit: int = 10):
            try:
                user_id = str(interaction.user.id)
                expenses = self.expense_manager.get_user_expenses(user_id)
                
                if not expenses:
                    await interaction.response.send_message("📝 You haven't recorded any expenses yet. Use `/add_expense` to get started!")
                    return
                
                # Filter by category if specified
                if category:
                    expenses = [exp for exp in expenses if exp['category'].lower() == category.lower()]
                    if not expenses:
                        await interaction.response.send_message(f"📝 No expenses found in category '{category}'")
                        return
                
                # Sort by date (most recent first) and limit
                expenses = sorted(expenses, key=lambda x: x['date'], reverse=True)[:limit]
                
                embed = discord.Embed(
                    title=f"💰 Your Recent Expenses" + (f" ({category.title()})" if category else ""),
                    color=0x3498db
                )
                
                total = sum(exp['amount'] for exp in expenses)
                
                expense_list = []
                for exp in expenses:
                    date_str = exp['date'].strftime("%m/%d")
                    expense_list.append(f"**${exp['amount']:.2f}** - {exp['description']} ({exp['category'].title()}) - {date_str}")
                
                if len(expense_list) > 10:
                    expense_list = expense_list[:10]
                    expense_list.append("... (use limit parameter to see more)")
                
                embed.description = "\n".join(expense_list)
                embed.add_field(name="Total Shown", value=f"${total:.2f}", inline=True)
                embed.add_field(name="Count", value=str(len(expenses)), inline=True)
                
                await interaction.response.send_message(embed=embed)
                
            except Exception as e:
                logger.error(f"Error viewing expenses: {e}")
                await interaction.response.send_message("❌ An error occurred while retrieving expenses", ephemeral=True)
        
        @self.bot.tree.command(name="expense_summary", description="Get a summary of your expenses by category")
        async def expense_summary(interaction: discord.Interaction):
            try:
                user_id = str(interaction.user.id)
                summary = self.expense_manager.get_expense_summary(user_id)
                
                if not summary:
                    await interaction.response.send_message("📝 You haven't recorded any expenses yet. Use `/add_expense` to get started!")
                    return
                
                embed = discord.Embed(
                    title="📊 Expense Summary",
                    color=0x9b59b6
                )
                
                total_amount = 0
                for category, data in summary.items():
                    total_amount += data['total']
                    embed.add_field(
                        name=f"{category.title()} ({data['count']} expenses)",
                        value=f"${data['total']:.2f}",
                        inline=True
                    )
                
                embed.add_field(name="📈 Grand Total", value=f"${total_amount:.2f}", inline=False)
                
                await interaction.response.send_message(embed=embed)
                
            except Exception as e:
                logger.error(f"Error getting expense summary: {e}")
                await interaction.response.send_message("❌ An error occurred while generating summary", ephemeral=True)
        
        @self.bot.tree.command(name="delete_expense", description="Delete an expense by ID")
        @discord.app_commands.describe(expense_id="The ID of the expense to delete")
        async def delete_expense(interaction: discord.Interaction, expense_id: str):
            try:
                user_id = str(interaction.user.id)
                success = self.expense_manager.delete_expense(user_id, expense_id)
                
                if success:
                    await interaction.response.send_message(f"✅ Expense {expense_id} has been deleted")
                else:
                    await interaction.response.send_message(f"❌ Expense {expense_id} not found or doesn't belong to you", ephemeral=True)
                
            except Exception as e:
                logger.error(f"Error deleting expense: {e}")
                await interaction.response.send_message("❌ An error occurred while deleting the expense", ephemeral=True)
        
        @self.bot.tree.command(name="help_expenses", description="Get help with expense commands")
        async def help_expenses(interaction: discord.Interaction):
            embed = discord.Embed(
                title="💡 Expense Bot Help",
                color=0xf39c12,
                description="Here are all the available commands:"
            )
            
            embed.add_field(
                name="/add_expense",
                value="Add a new expense\n*Example: /add_expense amount:12.50 description:Lunch category:food*",
                inline=False
            )
            
            embed.add_field(
                name="/view_expenses",
                value="View your recent expenses\n*Example: /view_expenses category:food limit:5*",
                inline=False
            )
            
            embed.add_field(
                name="/expense_summary",
                value="Get a summary of expenses by category",
                inline=False
            )
            
            embed.add_field(
                name="/delete_expense",
                value="Delete an expense by ID\n*Example: /delete_expense expense_id:abc123*",
                inline=False
            )
            
            embed.add_field(
                name="Categories",
                value="food, transport, utilities, entertainment, shopping, other",
                inline=False
            )
            
            await interaction.response.send_message(embed=embed)
    
    def handle_slash_command(self, interaction_data):
        """Handle slash command interactions for webhook mode"""
        # This is for webhook mode - would need to implement command parsing
        # For now, return a basic response
        return {
            'type': 4,
            'data': {
                'content': 'Please use the Discord bot directly for commands. Webhook mode is for verification only.'
            }
        }
    
    def run(self):
        """Run the Discord bot"""
        if self.bot_token and self.bot_token != "your_bot_token_here":
            self.bot.run(self.bot_token)
        else:
            logger.warning("Discord bot token not configured")
if __name__ == "__main__":
    from expense_manager import ExpenseManager

    manager = ExpenseManager()
    bot = DiscordBot(manager)
    bot.run()

@bot.command()
async def log(ctx, item: str, amount: float, note: str = ""):
    if sheet:
        try:
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M")
            user = ctx.author.name
            sheet.append_row([timestamp, item, amount, note, user])
            await ctx.send(f"✅ Logged: `{item}` - RM{amount:.2f} by {user}")
        except Exception as e:
            await ctx.send(f"❌ Failed to write to sheet: {e}")
    else:
        await ctx.send("❌ Google Sheet is not connected.")
