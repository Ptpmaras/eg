#!/usr/bin/env python3
import os
import discord
import asyncio

async def test_discord_connection():
    """Test Discord bot connection"""
    token = os.environ.get("DISCORD_BOT_TOKEN", "").strip()
    
    print(f"Testing Discord token...")
    print(f"Token length: {len(token)}")
    print(f"Token starts with: {token[:10]}...")
    print(f"Token ends with: ...{token[-10:]}")
    
    if not token:
        print("❌ No Discord token found")
        return False
    
    # Test basic Discord connection
    intents = discord.Intents.default()
    intents.message_content = True
    
    client = discord.Client(intents=intents)
    
    @client.event
    async def on_ready():
        print(f"✅ Successfully connected as {client.user}")
        await client.close()
    
    try:
        await client.start(token)
        return True
    except discord.LoginFailure as e:
        print(f"❌ Discord login failed: {e}")
        return False
    except Exception as e:
        print(f"❌ Discord connection error: {e}")
        return False

if __name__ == "__main__":
    asyncio.run(test_discord_connection())