# sheets_manager.py
import gspread
from oauth2client.service_account import ServiceAccountCredentials
from datetime import datetime

class GoogleSheetsManager:
    def __init__(self, creds_file="creds.json", sheet_name="Daily Expenses Bot"):
        scope = ["https://spreadsheets.google.com/feeds", "https://www.googleapis.com/auth/drive"]
        creds = ServiceAccountCredentials.from_json_keyfile_name(creds_file, scope)
        self.client = gspread.authorize(creds)
        self.sheet = self.client.open(sheet_name).sheet1

    def add_expense(self, expense: dict):
        self.sheet.append_row([
            expense['date'].strftime("%Y-%m-%d %H:%M:%S"),
            expense['user_id'],
            expense['amount'],
            expense['category'],
            expense['description'],
            expense['id']
        ])
