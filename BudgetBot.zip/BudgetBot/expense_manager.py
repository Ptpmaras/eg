import uuid
import logging
from datetime import datetime
from typing import Dict, List, Optional
from collections import defaultdict

logger = logging.getLogger(__name__)

class ExpenseManager:
    def __init__(self):
        # In-memory storage: user_id -> list of expenses
        self.user_expenses: Dict[str, List[Dict]] = defaultdict(list)
        
        # Valid expense categories
        self.valid_categories = {
            'food', 'transport', 'utilities', 'entertainment', 'shopping', 'rumah', 'bills', 'setel', 'maybank cc', 'spay later','other'
        }
    
    def add_expense(self, user_id: str, amount: float, description: str, category: str) -> str:
        """Add a new expense for a user"""
        try:
            # Validate category
            if category.lower() not in self.valid_categories:
                raise ValueError(f"Invalid category: {category}")
            
            # Generate unique expense ID
            expense_id = str(uuid.uuid4())[:8]
            
            # Create expense record
            expense = {
                'id': expense_id,
                'amount': round(float(amount), 2),
                'description': description.strip(),
                'category': category.lower(),
                'date': datetime.now(),
                'user_id': user_id
            }
            
            # Add to user's expenses
            self.user_expenses[user_id].append(expense)
            
            logger.info(f"Added expense {expense_id} for user {user_id}: ${amount:.2f} - {description}")
            return expense_id
            
        except Exception as e:
            logger.error(f"Error adding expense: {e}")
            raise
    
    def get_user_expenses(self, user_id: str) -> List[Dict]:
        """Get all expenses for a specific user"""
        try:
            return self.user_expenses.get(user_id, []).copy()
        except Exception as e:
            logger.error(f"Error getting expenses for user {user_id}: {e}")
            return []
    
    def get_expense_summary(self, user_id: str) -> Dict[str, Dict]:
        """Get expense summary by category for a user"""
        try:
            expenses = self.user_expenses.get(user_id, [])
            summary = defaultdict(lambda: {'total': 0.0, 'count': 0})
            
            for expense in expenses:
                category = expense['category']
                summary[category]['total'] += expense['amount']
                summary[category]['count'] += 1
            
            # Round totals to 2 decimal places
            for category_data in summary.values():
                category_data['total'] = round(category_data['total'], 2)
            
            return dict(summary)
            
        except Exception as e:
            logger.error(f"Error getting expense summary for user {user_id}: {e}")
            return {}
    
    def delete_expense(self, user_id: str, expense_id: str) -> bool:
        """Delete an expense by ID for a specific user"""
        try:
            user_expenses = self.user_expenses.get(user_id, [])
            
            for i, expense in enumerate(user_expenses):
                if expense['id'] == expense_id:
                    deleted_expense = user_expenses.pop(i)
                    logger.info(f"Deleted expense {expense_id} for user {user_id}: ${deleted_expense['amount']:.2f}")
                    return True
            
            logger.warning(f"Expense {expense_id} not found for user {user_id}")
            return False
            
        except Exception as e:
            logger.error(f"Error deleting expense {expense_id} for user {user_id}: {e}")
            return False
    
    def get_all_users(self) -> List[str]:
        """Get list of all user IDs with expenses"""
        return list(self.user_expenses.keys())
    
    def get_all_expenses(self) -> Dict[str, List[Dict]]:
        """Get all expenses for all users (admin/debug function)"""
        try:
            return dict(self.user_expenses)
        except Exception as e:
            logger.error(f"Error getting all expenses: {e}")
            return {}
    
    def get_total_expenses_count(self) -> int:
        """Get total number of expenses across all users"""
        try:
            return sum(len(expenses) for expenses in self.user_expenses.values())
        except Exception as e:
            logger.error(f"Error getting total expenses count: {e}")
            return 0
    
    def get_user_total_spent(self, user_id: str) -> float:
        """Get total amount spent by a user"""
        try:
            expenses = self.user_expenses.get(user_id, [])
            total = sum(expense['amount'] for expense in expenses)
            return round(total, 2)
        except Exception as e:
            logger.error(f"Error getting total spent for user {user_id}: {e}")
            return 0.0
    
    def search_expenses(self, user_id: str, query: str) -> List[Dict]:
        """Search expenses by description or category"""
        try:
            expenses = self.user_expenses.get(user_id, [])
            query_lower = query.lower()
            
            matching_expenses = []
            for expense in expenses:
                if (query_lower in expense['description'].lower() or 
                    query_lower in expense['category'].lower()):
                    matching_expenses.append(expense)
            
            return matching_expenses
            
        except Exception as e:
            logger.error(f"Error searching expenses for user {user_id}: {e}")
            return []
    
    def get_expenses_by_category(self, user_id: str, category: str) -> List[Dict]:
        """Get all expenses for a specific category"""
        try:
            expenses = self.user_expenses.get(user_id, [])
            category_lower = category.lower()
            
            return [exp for exp in expenses if exp['category'] == category_lower]
            
        except Exception as e:
            logger.error(f"Error getting expenses by category for user {user_id}: {e}")
            return []
    
    def get_recent_expenses(self, user_id: str, limit: int = 10) -> List[Dict]:
        """Get recent expenses for a user, sorted by date"""
        try:
            expenses = self.user_expenses.get(user_id, [])
            sorted_expenses = sorted(expenses, key=lambda x: x['date'], reverse=True)
            return sorted_expenses[:limit]
        except Exception as e:
            logger.error(f"Error getting recent expenses for user {user_id}: {e}")
            return []
