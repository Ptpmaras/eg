import os
import logging
from flask import Flask, render_template, request, jsonify
from werkzeug.middleware.proxy_fix import ProxyFix
from expense_manager import ExpenseManager
import threading
import asyncio

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Create Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "discord-expense-bot-secret")
app.wsgi_app = ProxyFix(app.wsgi_app, x_proto=1, x_host=1)

# Initialize expense manager
expense_manager = ExpenseManager()

# Discord bot will be initialized separately if token is available
discord_bot = None

def get_bot_status():
    """Check if Discord bot is ready"""
    global discord_bot
    if discord_bot is None:
        return False
    try:
        return discord_bot.is_ready()
    except:
        return False

@app.route('/')
def index():
    """Main dashboard showing bot status and basic stats"""
    total_users = len(expense_manager.get_all_users())
    total_expenses = sum(len(expenses) for expenses in expense_manager.user_expenses.values())
    
    return render_template('index.html', 
                         bot_status=get_bot_status(),
                         total_users=total_users,
                         total_expenses=total_expenses)

@app.route('/expenses')
def expenses():
    """Show all expenses (for admin/debugging purposes)"""
    all_expenses = expense_manager.get_all_expenses()
    return render_template('expenses.html', all_expenses=all_expenses)

@app.route('/interactions', methods=['POST'])
def handle_discord_interaction():
    """Handle Discord slash command interactions via webhook"""
    try:
        interaction_data = request.json
        if not interaction_data:
            return jsonify({'error': 'No interaction data'}), 400
        
        logger.debug(f"Received interaction: {interaction_data}")
        
        # Verify the interaction is from Discord (in production, you'd verify the signature)
        if interaction_data.get('type') == 1:  # PING
            return jsonify({'type': 1})
        
        if interaction_data.get('type') == 2:  # APPLICATION_COMMAND
            # Handle the slash command
            global discord_bot
            if discord_bot is not None:
                response = discord_bot.handle_slash_command(interaction_data)
                return jsonify(response)
            else:
                return jsonify({'type': 4, 'data': {'content': 'Discord bot is not available'}})
        
        return jsonify({'type': 4, 'data': {'content': 'Unknown interaction type'}})
        
    except Exception as e:
        logger.error(f"Error handling interaction: {e}")
        return jsonify({'type': 4, 'data': {'content': 'An error occurred processing your command'}}), 500

@app.route('/api/expenses/<user_id>')
def get_user_expenses(user_id):
    """API endpoint to get expenses for a specific user"""
    try:
        expenses = expense_manager.get_user_expenses(user_id)
        return jsonify({'expenses': expenses})
    except Exception as e:
        logger.error(f"Error fetching expenses for user {user_id}: {e}")
        return jsonify({'error': 'Failed to fetch expenses'}), 500

def initialize_discord_bot():
    """Initialize Discord bot if token is available"""
    global discord_bot
    bot_token = os.environ.get("DISCORD_BOT_TOKEN")
    if bot_token and bot_token != "MTM5ODExNjAxNzA0MDkxNjU0MA.GCPt6z.bzJikY9lIIgd9bPz27fO_isysG3NiB_k5u_5s8":
        try:
            from bot import DiscordBot
            discord_bot = DiscordBot(expense_manager)
            logger.info("Discord bot initialized successfully")
        except Exception as e:
            logger.error(f"Failed to initialize Discord bot: {e}")
    else:
        logger.info("DISCORD_BOT_TOKEN not found. Bot features will be disabled.")

def run_discord_bot():
    """Run the Discord bot in a separate thread"""
    global discord_bot
    if discord_bot:
        try:
            discord_bot.run()
        except Exception as e:
            logger.error(f"Discord bot error: {e}")

# Initialize Discord bot when Flask app starts
initialize_discord_bot()

# Start Discord bot in a separate thread if available (works with gunicorn)
if discord_bot:
    bot_thread = threading.Thread(target=run_discord_bot, daemon=True)
    bot_thread.start()
    logger.info("Discord bot started in background thread")

if __name__ == '__main__':
    # Start Flask app
    app.run(host='0.0.0.0', port=5000, debug=True)
